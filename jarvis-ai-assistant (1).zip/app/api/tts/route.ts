export const maxDuration = 30

const DEFAULT_VOICE_ID = 'pNInz6obpgDQGcFmaJgB' // ElevenLabs "Adam" — calm male preset fallback

export async function POST(req: Request) {
  const apiKey = process.env.ELEVENLABS_API_KEY
  if (!apiKey) {
    return Response.json(
      { error: 'ElevenLabs is not configured.' },
      { status: 500 },
    )
  }

  let text: string
  try {
    const body = await req.json()
    text = (body?.text ?? '').toString().trim()
  } catch {
    return Response.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  if (!text) {
    return Response.json({ error: 'No text provided.' }, { status: 400 })
  }

  // ElevenLabs caps input length; keep it sane for latency.
  const input = text.slice(0, 2500)
  const voiceId = process.env.ELEVENLABS_VOICE_ID || DEFAULT_VOICE_ID

  try {
    const res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream?optimize_streaming_latency=3`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json',
          Accept: 'audio/mpeg',
        },
        body: JSON.stringify({
          text: input,
          model_id: 'eleven_turbo_v2_5',
          voice_settings: {
            stability: 0.4,
            similarity_boost: 0.75,
            style: 0.25,
            use_speaker_boost: true,
          },
        }),
      },
    )

    if (!res.ok || !res.body) {
      const detail = await res.text()
      console.log('[v0] ElevenLabs error:', res.status, detail)
      return Response.json(
        { error: `Text-to-speech failed (${res.status}).` },
        { status: 502 },
      )
    }

    return new Response(res.body, {
      headers: {
        'Content-Type': 'audio/mpeg',
        'Cache-Control': 'no-store',
      },
    })
  } catch (err) {
    console.log('[v0] ElevenLabs exception:', (err as Error).message)
    return Response.json(
      { error: 'Text-to-speech threw an exception.' },
      { status: 500 },
    )
  }
}
