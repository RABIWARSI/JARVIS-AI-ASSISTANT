'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

interface UseTextToSpeechOptions {
  onStart?: () => void
  onEnd?: () => void
}

export function useTextToSpeech({ onStart, onEnd }: UseTextToSpeechOptions = {}) {
  const [speaking, setSpeaking] = useState(false)
  const [amplitude, setAmplitude] = useState(0)

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null)
  const rafRef = useRef<number | null>(null)
  const objectUrlRef = useRef<string | null>(null)

  const onStartRef = useRef(onStart)
  const onEndRef = useRef(onEnd)
  useEffect(() => {
    onStartRef.current = onStart
    onEndRef.current = onEnd
  }, [onStart, onEnd])

  const cleanupUrl = useCallback(() => {
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current)
      objectUrlRef.current = null
    }
  }, [])

  const tick = useCallback(() => {
    const analyser = analyserRef.current
    if (!analyser) return
    const data = new Uint8Array(analyser.frequencyBinCount)
    analyser.getByteFrequencyData(data)
    let sum = 0
    for (let i = 0; i < data.length; i++) sum += data[i]
    const avg = sum / data.length / 255
    setAmplitude(avg)
    rafRef.current = requestAnimationFrame(tick)
  }, [])

  const stop = useCallback(() => {
    const audio = audioRef.current
    if (audio) {
      audio.pause()
      audio.currentTime = 0
    }
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
    setAmplitude(0)
    setSpeaking(false)
  }, [])

  const speak = useCallback(
    async (text: string) => {
      const trimmed = text.trim()
      if (!trimmed) return

      stop()

      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: trimmed }),
        })
        if (!res.ok) {
          console.log('[v0] TTS fetch failed:', res.status)
          onEndRef.current?.()
          return
        }
        const blob = await res.blob()
        cleanupUrl()
        const url = URL.createObjectURL(blob)
        objectUrlRef.current = url

        let audio = audioRef.current
        if (!audio) {
          audio = new Audio()
          audio.crossOrigin = 'anonymous'
          audioRef.current = audio
        }
        audio.src = url

        // Lazily create the audio analysis graph.
        if (!audioCtxRef.current) {
          const Ctx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext })
              .webkitAudioContext
          const ctx = new Ctx()
          audioCtxRef.current = ctx
          const source = ctx.createMediaElementSource(audio)
          const analyser = ctx.createAnalyser()
          analyser.fftSize = 256
          source.connect(analyser)
          analyser.connect(ctx.destination)
          sourceRef.current = source
          analyserRef.current = analyser
        }
        await audioCtxRef.current.resume()

        audio.onplay = () => {
          setSpeaking(true)
          onStartRef.current?.()
          if (rafRef.current) cancelAnimationFrame(rafRef.current)
          rafRef.current = requestAnimationFrame(tick)
        }
        audio.onended = () => {
          stop()
          onEndRef.current?.()
        }
        audio.onerror = () => {
          stop()
          onEndRef.current?.()
        }

        await audio.play()
      } catch (err) {
        console.log('[v0] TTS exception:', (err as Error).message)
        onEndRef.current?.()
      }
    },
    [stop, tick, cleanupUrl],
  )

  useEffect(() => {
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      cleanupUrl()
      audioCtxRef.current?.close().catch(() => {})
    }
  }, [cleanupUrl])

  return { speak, stop, speaking, amplitude }
}
