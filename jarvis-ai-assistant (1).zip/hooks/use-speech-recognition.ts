'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import type {
  SpeechRecognition,
  SpeechRecognitionErrorEvent,
  SpeechRecognitionEvent,
} from '@/lib/speech-types'

export type RecognitionMode = 'idle' | 'wake' | 'command'

interface UseSpeechRecognitionOptions {
  /** Called with the final transcript when a command finishes. */
  onCommand?: (transcript: string) => void
  /** Called when the wake word is detected while in wake mode. */
  onWake?: () => void
  /** Wake word to listen for (lowercase). */
  wakeWord?: string
}

export function useSpeechRecognition({
  onCommand,
  onWake,
  wakeWord = 'jarvis',
}: UseSpeechRecognitionOptions) {
  const [supported, setSupported] = useState(true)
  const [mode, setMode] = useState<RecognitionMode>('idle')
  const [interim, setInterim] = useState('')
  const [error, setError] = useState<string | null>(null)

  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const modeRef = useRef<RecognitionMode>('idle')
  const shouldRunRef = useRef(false)
  const commandBufferRef = useRef('')
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Keep latest callbacks without re-creating recognition.
  const onCommandRef = useRef(onCommand)
  const onWakeRef = useRef(onWake)
  useEffect(() => {
    onCommandRef.current = onCommand
    onWakeRef.current = onWake
  }, [onCommand, onWake])

  const clearSilenceTimer = useCallback(() => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current)
      silenceTimerRef.current = null
    }
  }, [])

  // Initialize the recognition instance once.
  useEffect(() => {
    if (typeof window === 'undefined') return
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!Ctor) {
      setSupported(false)
      return
    }

    const recognition = new Ctor()
    recognition.lang = 'en-US'
    recognition.continuous = true
    recognition.interimResults = true
    recognition.maxAlternatives = 1

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interimText = ''
      let finalText = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        const transcript = result[0].transcript
        if (result.isFinal) finalText += transcript
        else interimText += transcript
      }

      const currentMode = modeRef.current

      if (currentMode === 'wake') {
        const haystack = (finalText + ' ' + interimText).toLowerCase()
        if (haystack.includes(wakeWord)) {
          onWakeRef.current?.()
        }
        // Don't surface wake-mode interim text as a command.
        return
      }

      if (currentMode === 'command') {
        if (interimText) setInterim(commandBufferRef.current + interimText)
        if (finalText) {
          commandBufferRef.current =
            (commandBufferRef.current + ' ' + finalText).trim()
          setInterim(commandBufferRef.current)
        }
        // Reset the silence countdown on any speech activity.
        clearSilenceTimer()
        silenceTimerRef.current = setTimeout(() => {
          const command = commandBufferRef.current.trim()
          commandBufferRef.current = ''
          setInterim('')
          if (command) onCommandRef.current?.(command)
        }, 1400)
      }
    }

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      if (event.error === 'no-speech' || event.error === 'aborted') return
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        setError('Microphone access was denied. Please allow it to use voice.')
        shouldRunRef.current = false
        modeRef.current = 'idle'
        setMode('idle')
        return
      }
      console.log('[v0] Speech recognition error:', event.error)
    }

    recognition.onend = () => {
      // The engine stops on its own periodically; restart if we still want to run.
      if (shouldRunRef.current) {
        try {
          recognition.start()
        } catch {
          /* already starting */
        }
      }
    }

    recognitionRef.current = recognition

    return () => {
      shouldRunRef.current = false
      try {
        recognition.abort()
      } catch {
        /* noop */
      }
    }
  }, [wakeWord, clearSilenceTimer])

  const startEngine = useCallback(() => {
    const recognition = recognitionRef.current
    if (!recognition) return
    shouldRunRef.current = true
    try {
      recognition.start()
    } catch {
      /* already running */
    }
  }, [])

  const stopEngine = useCallback(() => {
    const recognition = recognitionRef.current
    shouldRunRef.current = false
    clearSilenceTimer()
    commandBufferRef.current = ''
    setInterim('')
    try {
      recognition?.stop()
    } catch {
      /* noop */
    }
  }, [clearSilenceTimer])

  const listenForWake = useCallback(() => {
    setError(null)
    modeRef.current = 'wake'
    setMode('wake')
    startEngine()
  }, [startEngine])

  const listenForCommand = useCallback(() => {
    setError(null)
    clearSilenceTimer()
    commandBufferRef.current = ''
    setInterim('')
    modeRef.current = 'command'
    setMode('command')
    startEngine()
  }, [startEngine, clearSilenceTimer])

  const stop = useCallback(() => {
    modeRef.current = 'idle'
    setMode('idle')
    stopEngine()
  }, [stopEngine])

  return {
    supported,
    mode,
    interim,
    error,
    listenForWake,
    listenForCommand,
    stop,
  }
}
