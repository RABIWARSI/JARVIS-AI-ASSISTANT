'use client'

import { useEffect, useRef } from 'react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Search, Loader2 } from 'lucide-react'

export interface TranscriptMessage {
  id: string
  role: 'user' | 'assistant'
  text: string
  searching?: boolean
  searchQuery?: string
}

interface TranscriptPanelProps {
  messages: TranscriptMessage[]
  streamingText?: string
  isThinking?: boolean
}

export function TranscriptPanel({
  messages,
  streamingText,
  isThinking,
}: TranscriptPanelProps) {
  const endRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streamingText, isThinking])

  const isEmpty = messages.length === 0 && !streamingText && !isThinking

  return (
    <ScrollArea className="h-full w-full">
      <div className="flex flex-col gap-4 p-4">
        {isEmpty && (
          <div className="mt-8 text-center font-mono text-xs leading-relaxed tracking-wider text-muted-foreground">
            <p className="text-hud-dim">{'// CONVERSATION LOG'}</p>
            <p className="mt-3">
              Say {'"'}
              <span className="text-hud">Jarvis</span>
              {'"'} to wake the assistant, or type a message below.
            </p>
          </div>
        )}

        {messages.map((m) => (
          <MessageBubble key={m.id} message={m} />
        ))}

        {isThinking && !streamingText && (
          <div className="flex items-center gap-2 font-mono text-xs tracking-wider text-hud">
            <Loader2 className="size-3.5 animate-spin" />
            PROCESSING...
          </div>
        )}

        {streamingText && (
          <MessageBubble
            message={{ id: 'streaming', role: 'assistant', text: streamingText }}
          />
        )}

        <div ref={endRef} />
      </div>
    </ScrollArea>
  )
}

function MessageBubble({ message }: { message: TranscriptMessage }) {
  const isUser = message.role === 'user'
  return (
    <div
      className={`flex flex-col gap-1 animate-flicker-in ${
        isUser ? 'items-end' : 'items-start'
      }`}
    >
      <span className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">
        {isUser ? 'USER' : 'JARVIS'}
      </span>
      <div
        className={`max-w-[88%] rounded-lg border px-3.5 py-2.5 text-sm leading-relaxed ${
          isUser
            ? 'border-border bg-secondary/60 text-secondary-foreground'
            : 'border-primary/30 bg-card text-card-foreground box-glow'
        }`}
      >
        {message.searching && (
          <div className="mb-2 flex items-center gap-2 border-b border-primary/20 pb-2 font-mono text-[11px] tracking-wide text-hud">
            <Search className="size-3" />
            Searching the web
            {message.searchQuery ? `: "${message.searchQuery}"` : '...'}
          </div>
        )}
        <p className="text-pretty whitespace-pre-wrap">{message.text}</p>
      </div>
    </div>
  )
}
