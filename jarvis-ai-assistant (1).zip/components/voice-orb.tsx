'use client'

import { useEffect, useRef } from 'react'

export type AssistantState =
  | 'offline'
  | 'idle'
  | 'wake'
  | 'listening'
  | 'thinking'
  | 'speaking'

interface VoiceOrbProps {
  state: AssistantState
  /** 0..1 audio amplitude while speaking. */
  amplitude?: number
}

const STATE_LABEL: Record<AssistantState, string> = {
  offline: 'OFFLINE',
  idle: 'STANDBY',
  wake: 'AWAITING WAKE WORD',
  listening: 'LISTENING',
  thinking: 'PROCESSING',
  speaking: 'RESPONDING',
}

export function VoiceOrb({ state, amplitude = 0 }: VoiceOrbProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const stateRef = useRef(state)
  const ampRef = useRef(amplitude)
  stateRef.current = state
  ampRef.current = amplitude

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf = 0
    let t = 0
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const size = 300
    canvas.width = size * dpr
    canvas.height = size * dpr
    ctx.scale(dpr, dpr)
    const cx = size / 2
    const cy = size / 2

    const cyan = 'oklch(0.82 0.14 198)'

    const draw = () => {
      t += 0.016
      const s = stateRef.current
      const amp = ampRef.current
      ctx.clearRect(0, 0, size, size)

      // Activity factor drives motion/energy per state.
      let energy = 0.12
      if (s === 'listening') energy = 0.4
      else if (s === 'thinking') energy = 0.55
      else if (s === 'speaking') energy = 0.5 + amp * 0.9
      else if (s === 'wake') energy = 0.22

      const dim = s === 'offline'

      // Core glow
      const coreR = 46 + Math.sin(t * 2) * 3 + (s === 'speaking' ? amp * 26 : 0)
      const grad = ctx.createRadialGradient(cx, cy, 2, cx, cy, coreR * 2.2)
      grad.addColorStop(0, dim ? 'rgba(120,140,150,0.35)' : 'rgba(120,230,255,0.95)')
      grad.addColorStop(0.4, dim ? 'rgba(80,100,110,0.15)' : 'rgba(60,190,230,0.35)')
      grad.addColorStop(1, 'rgba(10,20,28,0)')
      ctx.fillStyle = grad
      ctx.beginPath()
      ctx.arc(cx, cy, coreR * 2.2, 0, Math.PI * 2)
      ctx.fill()

      // Waveform ring
      const points = 96
      const baseR = 78
      ctx.beginPath()
      for (let i = 0; i <= points; i++) {
        const angle = (i / points) * Math.PI * 2
        const noise =
          Math.sin(angle * 6 + t * 3) * 4 * energy +
          Math.sin(angle * 11 - t * 2) * 3 * energy +
          (s === 'speaking' ? Math.sin(angle * 18 + t * 9) * amp * 22 : 0)
        const r = baseR + noise
        const x = cx + Math.cos(angle) * r
        const y = cy + Math.sin(angle) * r
        if (i === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
      }
      ctx.closePath()
      ctx.strokeStyle = dim ? 'rgba(120,140,150,0.4)' : cyan
      ctx.lineWidth = 2
      ctx.shadowBlur = dim ? 0 : 16
      ctx.shadowColor = cyan
      ctx.stroke()
      ctx.shadowBlur = 0

      // Rotating tick ring
      const tickR = 110
      const ticks = 60
      const rot = t * (s === 'thinking' ? 1.4 : 0.3)
      for (let i = 0; i < ticks; i++) {
        const a = (i / ticks) * Math.PI * 2 + rot
        const long = i % 5 === 0
        const inner = tickR
        const outer = tickR + (long ? 10 : 5)
        ctx.beginPath()
        ctx.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner)
        ctx.lineTo(cx + Math.cos(a) * outer, cy + Math.sin(a) * outer)
        ctx.strokeStyle = dim
          ? 'rgba(120,140,150,0.25)'
          : `rgba(120,230,255,${long ? 0.7 : 0.3})`
        ctx.lineWidth = long ? 1.6 : 1
        ctx.stroke()
      }

      raf = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <div className="relative flex flex-col items-center justify-center">
      {/* Outer decorative rings */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <div
          className={`absolute size-[340px] rounded-full border border-primary/15 ${
            state !== 'offline' ? 'animate-spin-slow' : ''
          }`}
          style={{ borderTopColor: 'oklch(0.82 0.14 198 / 0.5)' }}
        />
        <div
          className={`absolute size-[392px] rounded-full border border-primary/10 ${
            state !== 'offline' ? 'animate-spin-reverse' : ''
          }`}
          style={{ borderBottomColor: 'oklch(0.82 0.14 198 / 0.35)' }}
        />
        <div className="absolute size-[300px] rounded-full border border-primary/10 animate-pulse-ring" />
      </div>

      <canvas
        ref={canvasRef}
        style={{ width: 300, height: 300 }}
        aria-hidden="true"
      />

      <div className="absolute bottom-2 flex flex-col items-center gap-1">
        <span
          className={`font-mono text-xs tracking-[0.3em] ${
            state === 'offline' ? 'text-muted-foreground' : 'text-hud text-glow'
          }`}
        >
          {STATE_LABEL[state]}
        </span>
      </div>
    </div>
  )
}
