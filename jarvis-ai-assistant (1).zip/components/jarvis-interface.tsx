'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport, type UIMessage } from 'ai'
import { Mic, MicOff, Power, Send, Volume2, VolumeX, AlertTriangle } from 'lucide-react'
import { useSpeechRecognition } from '@/hooks/use-speech-recognition'
import { useTextToSpeech } from '@/hooks/use-text-to-speech'
import { VoiceOrb, type AssistantState } from '@/components/voice-orb'
import { TranscriptPanel, type TranscriptMessage } from '@/components/transcript-panel'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

function getMessageText(msg: UIMessage): string {
  if (!msg.parts) return ''
  return msg.parts
    .filter((p): p is { type: 'text'; text: string } => p.type === 'text')
    .map((p) => p.text)
    .join('')
}

function getSearchInfo(msg: UIMessage): { searching: boolean; query?: string } {
  if (!msg.parts) return { searching: false }
  for (const part of msg.parts) {
    // Tool parts are typed as `tool-<name>`.
    const p = part as { type: string; state?: string; input?: { query?: string } }
    if (p.type === 'tool-webSearch') {
      const active = p.state === 'input-available' || p.state === 'input-streaming'
      return { searching: active, query: p.input?.query }
    }
  }
  return { searching: false }
}

export function JarvisInterface() {
  const [active, setActive] = useState(false)
  const [wakeEnabled, setWakeEnabled] = useState(true)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [textInput, setTextInput] = useState('')
  const [spokenIds, setSpokenIds] = useState<Set<string>>(new Set())

  const voiceEnabledRef = useRef(voiceEnabled)
  voiceEnabledRef.current = voiceEnabled
  const wakeEnabledRef = useRef(wakeEnabled)
  wakeEnabledRef.current = wakeEnabled

  const { messages, sendMessage, status, error } = useChat({
    transport: new DefaultChatTransport({ api: '/api/chat' }),
  })

  const isBusy = status === 'submitted' || status === 'streaming'

  const tts = useTextToSpeech({
    onEnd: () => {
      // Return to wake-listening after speaking, if enabled.
      if (active && wakeEnabledRef.current) speech.listenForWake()
    },
  })

  const speech = useSpeechRecognition({
    wakeWord: 'jarvis',
    onWake: () => {
      tts.stop()
      speech.listenForCommand()
    },
    onCommand: (transcript) => {
      sendMessage({ text: transcript })
    },
  })

  // Derive the high-level assistant state for the orb.
  const assistantState: AssistantState = useMemo(() => {
    if (!active) return 'offline'
    if (tts.speaking) return 'speaking'
    if (isBusy) return 'thinking'
    if (speech.mode === 'command') return 'listening'
    if (speech.mode === 'wake') return 'wake'
    return 'idle'
  }, [active, tts.speaking, isBusy, speech.mode])

  // Speak newly completed assistant messages.
  useEffect(() => {
    if (!active || !voiceEnabled) return
    if (status !== 'ready') return
    const last = messages[messages.length - 1]
    if (!last || last.role !== 'assistant') return
    if (spokenIds.has(last.id)) return
    const text = getMessageText(last)
    if (!text.trim()) return
    setSpokenIds((prev) => new Set(prev).add(last.id))
    tts.speak(text)
  }, [messages, status, active, voiceEnabled, spokenIds, tts])

  // Power the assistant on/off.
  const togglePower = useCallback(() => {
    setActive((prev) => {
      const next = !prev
      if (next) {
        if (wakeEnabledRef.current) speech.listenForWake()
      } else {
        speech.stop()
        tts.stop()
      }
      return next
    })
  }, [speech, tts])

  // React to wake-mode toggle while active.
  useEffect(() => {
    if (!active) return
    if (wakeEnabled && speech.mode === 'idle' && !isBusy && !tts.speaking) {
      speech.listenForWake()
    }
    if (!wakeEnabled && speech.mode === 'wake') {
      speech.stop()
    }
  }, [wakeEnabled, active, speech, isBusy, tts.speaking])

  const handleManualMic = useCallback(() => {
    if (!active) return
    if (speech.mode === 'command') {
      speech.stop()
    } else {
      tts.stop()
      speech.listenForCommand()
    }
  }, [active, speech, tts])

  const handleSubmitText = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault()
      const text = textInput.trim()
      if (!text) return
      sendMessage({ text })
      setTextInput('')
    },
    [textInput, sendMessage],
  )

  // Build transcript messages for display.
  const transcriptMessages: TranscriptMessage[] = useMemo(() => {
    return messages
      .map((m) => {
        const text = getMessageText(m)
        const { searching, query } = getSearchInfo(m)
        return {
          id: m.id,
          role: m.role as 'user' | 'assistant',
          text,
          searching,
          searchQuery: query,
        }
      })
      .filter((m) => m.text.trim() || m.searching)
  }, [messages])

  if (!speech.supported) {
    return (
      <div className="mx-auto mt-20 max-w-md rounded-lg border border-alert/40 bg-card p-6 text-center">
        <AlertTriangle className="mx-auto size-8 text-alert" />
        <h2 className="mt-3 font-mono text-sm tracking-wider text-foreground">
          VOICE NOT SUPPORTED
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Your browser does not support the Web Speech API. Please use Chrome or
          Edge on desktop for voice features. Text chat still works below.
        </p>
      </div>
    )
  }

  return (
    <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-5xl flex-col gap-6 px-4 py-6">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-primary/20 pb-4">
        <div className="flex items-center gap-3">
          <div
            className={`size-2.5 rounded-full ${
              active ? 'bg-hud shadow-[0_0_10px_var(--hud)]' : 'bg-muted-foreground/40'
            }`}
          />
          <div>
            <h1 className="font-mono text-lg font-semibold tracking-[0.35em] text-foreground text-glow">
              J.A.R.V.I.S
            </h1>
            <p className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">
              JUST A RATHER VERY INTELLIGENT SYSTEM
            </p>
          </div>
        </div>
        <Button
          onClick={togglePower}
          variant="outline"
          className={`gap-2 border-primary/40 font-mono text-xs tracking-wider ${
            active ? 'text-hud' : 'text-muted-foreground'
          }`}
        >
          <Power className="size-4" />
          {active ? 'ONLINE' : 'OFFLINE'}
        </Button>
      </header>

      <div className="grid flex-1 gap-6 lg:grid-cols-[1fr_minmax(320px,420px)]">
        {/* Left: Orb + controls */}
        <section className="flex flex-col items-center justify-center gap-8 rounded-xl border border-primary/15 bg-card/40 p-6 box-glow">
          <div className="flex flex-1 items-center justify-center py-6">
            <VoiceOrb state={assistantState} amplitude={tts.amplitude} />
          </div>

          {/* Live interim transcript */}
          <div className="min-h-6 max-w-full text-center">
            {speech.interim ? (
              <p className="font-mono text-sm text-hud text-glow">
                {speech.interim}
              </p>
            ) : (
              <p className="font-mono text-xs tracking-wider text-muted-foreground">
                {active
                  ? assistantState === 'wake'
                    ? 'Listening for "Jarvis"...'
                    : assistantState === 'listening'
                      ? 'Speak now...'
                      : ''
                  : 'System offline'}
              </p>
            )}
          </div>

          {speech.error && (
            <p className="flex items-center gap-2 font-mono text-xs text-alert">
              <AlertTriangle className="size-3.5" />
              {speech.error}
            </p>
          )}

          {/* Controls */}
          <div className="flex w-full flex-col gap-4">
            <div className="flex items-center justify-center gap-3">
              <Button
                onClick={handleManualMic}
                disabled={!active}
                size="lg"
                className={`size-16 rounded-full ${
                  assistantState === 'listening'
                    ? 'bg-hud text-primary-foreground'
                    : 'bg-secondary text-foreground'
                }`}
                aria-label={
                  assistantState === 'listening' ? 'Stop listening' : 'Start talking'
                }
              >
                {assistantState === 'listening' ? (
                  <MicOff className="size-6" />
                ) : (
                  <Mic className="size-6" />
                )}
              </Button>
            </div>

            <div className="flex items-center justify-between gap-4 border-t border-primary/15 pt-4">
              <label className="flex items-center gap-2 font-mono text-xs tracking-wider text-muted-foreground">
                <Switch
                  checked={wakeEnabled}
                  onCheckedChange={setWakeEnabled}
                  aria-label="Toggle wake word"
                />
                WAKE MODE
              </label>
              <button
                type="button"
                onClick={() => {
                  setVoiceEnabled((v) => !v)
                  if (voiceEnabled) tts.stop()
                }}
                className="flex items-center gap-2 font-mono text-xs tracking-wider text-muted-foreground transition-colors hover:text-hud"
              >
                {voiceEnabled ? (
                  <Volume2 className="size-4 text-hud" />
                ) : (
                  <VolumeX className="size-4" />
                )}
                VOICE {voiceEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>
        </section>

        {/* Right: Transcript + text input */}
        <section className="flex min-h-[420px] flex-col rounded-xl border border-primary/15 bg-card/40">
          <div className="flex items-center gap-2 border-b border-primary/20 px-4 py-3">
            <span className="size-1.5 rounded-full bg-hud" />
            <h2 className="font-mono text-xs tracking-[0.25em] text-muted-foreground">
              CONVERSATION
            </h2>
          </div>

          <div className="flex-1 overflow-hidden">
            <TranscriptPanel
              messages={transcriptMessages}
              isThinking={isBusy}
            />
          </div>

          {error && (
            <p className="border-t border-alert/30 px-4 py-2 font-mono text-xs text-alert">
              Connection error. Please try again.
            </p>
          )}

          <form
            onSubmit={handleSubmitText}
            className="flex items-center gap-2 border-t border-primary/20 p-3"
          >
            <Input
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Type a message..."
              className="border-primary/20 bg-input/40 font-sans text-sm focus-visible:ring-primary/40"
            />
            <Button
              type="submit"
              size="icon"
              disabled={!textInput.trim() || isBusy}
              className="shrink-0 bg-primary text-primary-foreground"
              aria-label="Send message"
            >
              <Send className="size-4" />
            </Button>
          </form>
        </section>
      </div>
    </div>
  )
}
