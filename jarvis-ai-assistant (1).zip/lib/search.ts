import 'server-only'

export interface SearchResult {
  title: string
  link: string
  snippet: string
}

/**
 * Performs a web search via SearchApi.io (Google engine) and returns the top
 * organic results. Requires SEARCHAPI_API_KEY.
 *
 * SearchApi.io offers a free tier and does not require a credit card, making it
 * a good fit for development and student projects.
 */
export async function webSearch(
  query: string,
  count = 5,
): Promise<{ results: SearchResult[]; error?: string }> {
  const apiKey = process.env.SEARCHAPI_API_KEY

  if (!apiKey) {
    return {
      results: [],
      error: 'Search is not configured. Missing SEARCHAPI_API_KEY.',
    }
  }

  const url = new URL('https://www.searchapi.io/api/v1/search')
  url.searchParams.set('engine', 'google')
  url.searchParams.set('q', query)
  url.searchParams.set('num', String(Math.min(Math.max(count, 1), 10)))

  try {
    const res = await fetch(url.toString(), {
      cache: 'no-store',
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    })

    if (!res.ok) {
      const body = await res.text()
      console.log('[v0] SearchApi error:', res.status, body)
      return { results: [], error: `Search request failed (${res.status}).` }
    }

    const data = (await res.json()) as {
      organic_results?: Array<{
        title?: string
        link?: string
        snippet?: string
      }>
      answer_box?: { answer?: string; snippet?: string; title?: string }
    }

    const results: SearchResult[] = []

    // Surface an answer box first when present — great for live facts/weather.
    if (data.answer_box) {
      const ab = data.answer_box
      const text = ab.answer ?? ab.snippet
      if (text) {
        results.push({
          title: ab.title ?? 'Featured answer',
          link: '',
          snippet: text,
        })
      }
    }

    for (const item of data.organic_results ?? []) {
      results.push({
        title: item.title ?? '',
        link: item.link ?? '',
        snippet: item.snippet ?? '',
      })
    }

    return { results: results.slice(0, count) }
  } catch (err) {
    console.log('[v0] SearchApi exception:', (err as Error).message)
    return { results: [], error: 'Search request threw an exception.' }
  }
}
